import math

# The header of the table
print("---------------------------------")
print(format("x", ">5s") + '|', format("x^2", "12s"), format("√x", "10s"))
print("---------------------------------")

print(format(5, ">5d") + '|', format(5 ** 2, "<12.2f"), format(math.sqrt(5), "<10.2f"))
print(format(500, ">5d") + '|', format(500 ** 2, "<12.2f"), format(math.sqrt(500), "<10.2f"))
print(format(20, ">5d") + '|', format(20 ** 2, "<12.2f"), format(math.sqrt(20), "<10.2f"))
print(format(3000, ">5d") + '|', format(3000 ** 2, "<12.2f"), format(math.sqrt(3000), "<10.2f"))

# The footer of the table
print("---------------------------------")