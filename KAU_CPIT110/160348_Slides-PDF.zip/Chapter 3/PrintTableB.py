import math

SEPARATOR = '|' # a constant to represent the separator between the first and second columns
FORMAT_1 = ">5d" # a constant to represent the Specifier for the first column format
FORMAT_2 = "<12.2f" # a constant to represent the Specifier for the second column format
FORMAT_3 = "<10.2f" # a constant to represent the Specifier for the first third format

# The header of the table
print("---------------------------------")
print(format("x", ">5s") + SEPARATOR, format("x^2", "12s"), format("√x", "10s"))
print("---------------------------------")

x = 5 # this variable stores the value of x that will be included with the next calculations
print(format(x, FORMAT_1) + SEPARATOR, format(x ** 2, FORMAT_2), format(math.sqrt(x), FORMAT_3))

x = 500 # change the value, so we don't need to change the previous statement to apply the change
print(format(x, FORMAT_1) + SEPARATOR, format(x ** 2, FORMAT_2), format(math.sqrt(x), FORMAT_3))

x = 20 # change the value, so we don't need to change the previous statement to apply the change
print(format(x, FORMAT_1) + SEPARATOR, format(x ** 2, FORMAT_2), format(math.sqrt(x), FORMAT_3))

x = 3000 # change the value, so we don't need to change the previous statement to apply the change
print(format(x, FORMAT_1) + SEPARATOR, format(x ** 2, FORMAT_2), format(math.sqrt(x), FORMAT_3))

# The footer of the table
print("---------------------------------")