# Convert Fahrenheit to Celsius
print("Fahrenheit 35 is Celsius degree ")
print(5 / 9 * 35 - 32)

# Correct result
print()
print("----------------------------------")
print("Correct Result", 5 / 9 * (35 - 32))