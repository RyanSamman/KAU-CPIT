# Display two messages
print("Welcome to Python")
print("Python is fun")