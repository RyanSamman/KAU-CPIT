x = int(True) + int(True) + int(int(True) - int(True))
y = int(True) * int(bool(50) * 3)
r = x + y
print("x = ", x)
print("y = ", y)
print("r = ", r)
print("bool(r) = ", bool(r))
print("bool(r - r) = ", bool(r - r))