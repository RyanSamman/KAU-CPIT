# Prompt the user to enter a radius
radius = eval(input("Enter a value for radius: "))

if radius < 0:
    # radius is negative, so print an error message
    print("Incorrect input")
else:
    # Compute area
    area = radius * radius * 3.14159
    # Display results
    print("The area for the circle of radius " , radius , " is " , area)