value1 = eval(input("Enter Value 1: "))
value2 = eval(input("Enter Value 2: "))
largest = max(value1, value2)
print("The largest value is ", largest)