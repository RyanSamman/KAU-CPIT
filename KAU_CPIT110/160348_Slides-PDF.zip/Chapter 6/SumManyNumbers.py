# Sum from 1 to 10
sum = 0
for i in range(1, 11):
    sum += i
print("Sum from 1 to 10 is", sum)

# Sum from 20 to 37
sum = 0
for i in range(20, 38):
    sum += i
print("Sum from 20 to 37 is", sum)

# Sum from 35 to 49
sum = 0
for i in range(35, 50):
    sum += i
print("Sum from 35 to 49 is", sum)