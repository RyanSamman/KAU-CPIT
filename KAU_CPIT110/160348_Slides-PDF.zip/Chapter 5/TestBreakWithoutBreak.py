sum = 0
number = 0
stop = False
while number < 20 and not stop:
    number += 1
    sum += number
    if sum >= 100:
        stop = True

print("The number is", number)
print("The sum is", sum)